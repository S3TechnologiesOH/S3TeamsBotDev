# run.sh

#!/bin/bash
node timer.js
